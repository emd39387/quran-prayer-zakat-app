# Quran App Starter Repo

This repository provides a scaffold for Quran reading, explanations, zakat, and prayer times app in multiple languages.