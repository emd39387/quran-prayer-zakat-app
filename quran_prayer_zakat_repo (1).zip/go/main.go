package main
import ("fmt")
func main() { fmt.Println("Quran App Go") }