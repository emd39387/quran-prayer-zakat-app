package com.example.quranapp
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
class MainActivity: AppCompatActivity() { override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); println("Quran App Kotlin") } }